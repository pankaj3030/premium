//used in only home page

$(document).ready(function () {
    //featured products slider
    $(".featuredproducts").jCarouselLite({
        btnNext: ".featurenxt",
        btnPrev: ".featureprev",
        auto: 4000,
        speed: 1200,
        visible: 4

    });


$(document).ajaxStop(function(){

     //brand slider
    $(".brandbanner").jCarouselLite({
        btnNext: ".brandnxt",
        btnPrev: ".brandprev",
        auto: 4000,
        speed: 1200,
        visible: 5,

    });
});


    //brand slider
    $(".brandbanner").jCarouselLite({
        btnNext: ".brandnxt",
        btnPrev: ".brandprev",
        auto: 4000,
        speed: 1200,
        visible: 5,

    });
});


        $(document).ready(function(){

         $('.SideCategoryListFlyout ul.sf-menu > li').each(function (i, li) {
    
        $( "ul.sf-menu > li > ul > li" ).addClass( "level1" );
        $( "ul.sf-menu > li > ul > li > ul > li" ).addClass( "level2" );
        $( "ul.sf-menu > li > ul > li > ul > li > ul > li" ).addClass( "level3" );
        $( "ul.sf-menu > li > ul > li > ul > li > ul > li > ul > li" ).addClass( "level4" );
        $( "ul.sf-menu > li > ul > li > ul > li > ul > li > ul > li > ul > li" ).addClass( "level5" );
       
        var lis = $(li).find('li.level1');
      
      
      for (var j=0; j < lis.length; j += 9) {      
        lis.slice(j, j + 9).wrapAll("<div class='li_group'> </div>");
      }
     
        

        var $product = $(li);
        if ($product.find('ul li.level1').length <= 9) {
            $(this).addClass('col1');
        } else {
            if ($product.find('ul li.level1').length > 18) {
                $(this).addClass('col3');
            } else {
                $(this).addClass('col2');
            }
        } 
      
      
        
    });
      
      
      
      
         // Submenu background
         if($("#Menu .sf-menu li ul").has("li").length == 0) {
            $("#Menu .sf-menu li ul").css("background","none");
         }

        // Aplly menuitem class in each li
        $('.SideCategoryListFlyout > .sf-menu > li').each( function( index ) {
		$(this).addClass('menuitem-'+ index);
        });
      }); 


// HTMLHead script 
      
     
      $(document).ready(function(){
          $(".p-price").each(function (index) {
               if($(this).find('span').hasClass('SalePrice')){
                  $(this).parent().append('<div class="new_tag"></div>');
               }

          });


          $('.cartbag a span').text(function(_, text) {
             return text.replace(/\(|\)/g, '');
          });

          $('.cartbag a span:contains("items")').each(function(){            
             $(this).html($(this).html().split("items") .join(""));
          });

          $('.cartbag a span:contains("item")').each(function(){
             $(this).html($(this).html().split("item") .join(""));
          });
       });
     
      $(document).ajaxStop(function(){
       $('.cartbag a span').text(function(_, text) {
      return text.replace(/\(|\)/g, '');
      });
      $('.cartbag a span:contains("items")').each(function(){
      $(this).html($(this).html().split("items") .join(""));
      });
      $('.cartbag a span:contains("item")').each(function(){
      $(this).html($(this).html().split("item") .join(""));
      });
       });
     
    


$(document).ready(function(){
    $('.ProductList li:nth-child(3n+1)').addClass('Firstblock');
    $('.ProductList li:nth-child(3n)').addClass('Lastblock');
});


$(document).ready(function() {
    var cartLength = $('#cart-items').text();
    if($('.cartbag a span').text().length ==0)
        {
         $('.cartbag a span').text("0");
        } 
    if(cartLength >= 1){
     $('.cart-detail .c-empty').hide();
    } 
});

   
  