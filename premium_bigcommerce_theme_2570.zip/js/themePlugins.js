(function(a) {
    a.fn.flexisel = function(k) {
        var e = a.extend({
            visibleItems: 4,
            animationSpeed: 200,
            autoPlay: false,
            autoPlaySpeed: 3000,
            pauseOnHover: true,
            setMaxWidthAndHeight: false,
            enableResponsiveBreakpoints: true,
            clone: true,
            responsiveBreakpoints: {
                portrait: {
                    changePoint: 480,
                    visibleItems: 1
                },
                landscape: {
                    changePoint: 640,
                    visibleItems: 2
                },
                tablet: {
                    changePoint: 768,
                    visibleItems: 3
                }
            }
        }, k);
        var f = a(this);
        var d = a.extend(e, k);
        var h;
        var i = true;
        var g = d.visibleItems;
        var j = f.children().length;
        var b = [];
        var c = {
            init: function() {
                return this.each(function() {
                    c.appendHTML();
                    c.setEventHandlers();
                    c.initializeItems()
                })
            },
            initializeItems: function() {
                var o = f.parent();
                var n = o.height();
                var m = f.children();
                c.sortResponsiveObject(d.responsiveBreakpoints);
                var l = o.width();
                h = (l) / g;
                m.width(h);
                if (d.clone) {
                    m.last().insertBefore(m.first());
                    m.last().insertBefore(m.first());
                    f.css({
                        left: -h
                    })
                }
                f.fadeIn();
                a(window).trigger("resize")
            },
            appendHTML: function() {
                f.addClass("nbs-flexisel-ul");
                f.wrap("<div class='nbs-flexisel-container'><div class='nbs-flexisel-inner'></div></div>");
                f.find("li").addClass("nbs-flexisel-item");
                if (d.setMaxWidthAndHeight) {
                    var n = a(".nbs-flexisel-item img").width();
                    var m = a(".nbs-flexisel-item img").height();
                    a(".nbs-flexisel-item img").css("max-width", n);
                    a(".nbs-flexisel-item img").css("max-height", m)
                }
                a("<div class='nbs-flexisel-nav-left'></div><div class='nbs-flexisel-nav-right'></div>").insertAfter(f);
                if (d.clone) {
                    var l = f.children().clone();
                    f.append(l)
                }
            },
            setEventHandlers: function() {
                var n = f.parent();
                var m = f.children();
                var o = n.find(a(".nbs-flexisel-nav-left"));
                var l = n.find(a(".nbs-flexisel-nav-right"));
                a(window).on("resize", function(q) {
                    c.setResponsiveEvents();
                    var p = a(n).width();
                    var r = a(n).height();
                    h = (p) / g;
                    m.width(h);
                    if (d.clone) {
                        f.css({
                            left: -h
                        })
                    } else {
                        f.css({
                            left: 0
                        })
                    }
                    var s = (o.height()) / 2;
                    var t = (r / 2) - s;
                    o.css("top", t + "px");
                    l.css("top", t + "px")
                });
                a(o).on("click", function(p) {
                    c.scrollLeft()
                });
                a(l).on("click", function(p) {
                    c.scrollRight()
                });
                if (d.pauseOnHover == true) {
                    a(".nbs-flexisel-item").on({
                        mouseenter: function() {
                            i = false
                        },
                        mouseleave: function() {
                            i = true
                        }
                    })
                }
                if (d.autoPlay == true) {
                    setInterval(function() {
                        if (i == true) {
                            c.scrollRight()
                        }
                    }, d.autoPlaySpeed)
                }
            },
            setResponsiveEvents: function() {
                var l = a("html").width();
                if (d.enableResponsiveBreakpoints) {
                    var n = b[b.length - 1].changePoint;
                    for (var m in b) {
                        if (l >= n) {
                            g = d.visibleItems;
                            break
                        } else {
                            if (l < b[m].changePoint) {
                                g = b[m].visibleItems;
                                break
                            } else {
                                continue
                            }
                        }
                    }
                }
            },
            sortResponsiveObject: function(n) {
                var l = [];
                for (var m in n) {
                    l.push(n[m])
                }
                l.sort(function(p, o) {
                    return p.changePoint - o.changePoint
                });
                b = l
            },
            scrollLeft: function() {
                if (f.position().left < 0) {
                    if (i == true) {
                        i = false;
                        var n = f.parent();
                        var l = n.width();
                        h = (l) / g;
                        var m = f.children();
                        f.animate({
                            left: "+=" + h
                        }, {
                            queue: false,
                            duration: d.animationSpeed,
                            easing: "linear",
                            complete: function() {
                                if (d.clone) {
                                    m.last().insertBefore(m.first())
                                }
                                c.adjustScroll();
                                i = true
                            }
                        })
                    }
                }
            },
            scrollRight: function() {
                var p = f.parent();
                var l = p.width();
                h = (l) / g;
                var o = (h - l);
                var n = (f.position().left + ((j - g) * h) - l);
                if ((o <= Math.ceil(n)) && (!d.clone)) {
                    if (i == true) {
                        i = false;
                        f.animate({
                            left: "-=" + h
                        }, {
                            queue: false,
                            duration: d.animationSpeed,
                            easing: "linear",
                            complete: function() {
                                c.adjustScroll();
                                i = true
                            }
                        })
                    }
                } else {
                    if (d.clone) {
                        if (i == true) {
                            i = false;
                            var m = f.children();
                            f.animate({
                                left: "-=" + h
                            }, {
                                queue: false,
                                duration: d.animationSpeed,
                                easing: "linear",
                                complete: function() {
                                    m.first().insertAfter(m.last());
                                    c.adjustScroll();
                                    i = true
                                }
                            })
                        }
                    }
                }
            },
            adjustScroll: function() {
                var n = f.parent();
                var m = f.children();
                var l = n.width();
                h = (l) / g;
                m.width(h);
                if (d.clone) {
                    f.css({
                        left: -h
                    })
                }
            }
        };
        if (c[k]) {
            return c[k].apply(this, Array.prototype.slice.call(arguments, 1))
        } else {
            if (typeof k === "object" || !k) {
                return c.init.apply(this)
            } else {
                a.error('Method "' + method + '" does not exist in flexisel plugin!')
            }
        }
    }
})(jQuery);
(function(a) {
    a.fn.extend({
        accordionmenu: function(b) {
            var e = {
                accordion: "true",
                speed: 300,
                closedSign: "[+]",
                openedSign: "[-]"
            };
            var c = a.extend(e, b);
            var d = a(this);
            d.find("li").each(function() {
                if (a(this).find("ul").size() != 0) {
                    a(this).find("a:first").after("<span>" + c.closedSign + "</span>");
                    if (a(this).find("a:first").attr("href") == "#") {
                        a(this).find("a:first").click(function() {
                            return false
                        })
                    }
                }
            });
            d.find("li.selected").each(function() {
                a(this).parents("ul").slideDown(c.speed);
                a(this).parents("ul").parent("li").find("span:first").html(c.openedSign)
            });
            d.find("li span").click(function() {
                if (a(this).parent().find("ul").size() != 0) {
                    if (c.accordion) {
                        if (!a(this).parent().find("ul").is(":visible")) {
                            parents = a(this).parent().parents("ul");
                            visible = d.find("ul:visible");
                            visible.each(function(f) {
                                var g = true;
                                parents.each(function(h) {
                                    if (parents[h] == visible[f]) {
                                        g = false;
                                        return false
                                    }
                                });
                                if (g) {
                                    if (a(this).parent().find("ul") != visible[f]) {
                                        a(visible[f]).slideUp(c.speed, function() {
                                            a(this).parent("li").find("span:first").html(c.closedSign)
                                        })
                                    }
                                }
                            })
                        }
                    }
                    if (a(this).parent().find("ul:first").is(":visible")) {
                        a(this).parent().find("ul:first").slideUp(c.speed, function() {
                            a(this).parent("li").find("span:first").delay(c.speed).html(c.closedSign)
                        })
                    } else {
                        a(this).parent().find("ul:first").slideDown(c.speed, function() {
                            a(this).parent("li").find("span:first").delay(c.speed).html(c.openedSign)
                        })
                    }
                }
            })
        }
    })
})(jQuery);
(function(d) {
    var b = !1,
        a = !1,
        f = {
            isUrl: function(h) {
                var g = RegExp("^(https?:\\/\\/)?((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|((\\d{1,3}\\.){3}\\d{1,3}))(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*(\\?[;&a-z\\d%_.~+=-]*)?(\\#[-a-z\\d_]*)?$", "i");
                return g.test(h) ? !0 : !1
            },
            loadContent: function(h, g) {
                h.html(g)
            },
            addPrefix: function(j) {
                var h = j.attr("id"),
                    g = j.attr("class");
                "string" == typeof h && "" !== h && j.attr("id", h.replace(/([A-Za-z0-9_.\-]+)/g, "sidr-id-$1")), "string" == typeof g && "" !== g && "sidr-inner" !== g && j.attr("class", g.replace(/([A-Za-z0-9_.\-]+)/g, "sidr-class-$1")), j.removeAttr("style")
            },
            execute: function(g, h, x) {
                "function" == typeof h ? (x = h, h = "sidr") : h || (h = "sidr");
                var r, k, i, m = d("#" + h),
                    j = d(m.data("body")),
                    w = d("html"),
                    e = m.outerWidth(!0),
                    q = m.data("speed"),
                    t = m.data("side");
                if ("open" === g || "toogle" === g && !m.is(":visible")) {
                    if (m.is(":visible") || b) {
                        return
                    }
                    if (a !== !1) {
                        return c.close(a, function() {
                            c.open(h)
                        }), void 0
                    }
                    b = !0, "left" === t ? (r = {
                        left: e + "px"
                    }, k = {
                        left: "0px"
                    }) : (r = {
                        right: e + "px"
                    }, k = {
                        right: "0px"
                    }), i = w.scrollTop(), w.css("overflow-x", "hidden").scrollTop(i), j.css({
                        width: j.width(),
                        position: "absolute"
                    }).animate(r, q), m.css("display", "block").animate(k, q, function() {
                        b = !1, a = h, "function" == typeof x && x(h)
                    })
                } else {
                    if (!m.is(":visible") || b) {
                        return
                    }
                    b = !0, "left" === t ? (r = {
                        left: 0
                    }, k = {
                        left: "-" + e + "px"
                    }) : (r = {
                        right: 0
                    }, k = {
                        right: "-" + e + "px"
                    }), i = w.scrollTop(), w.removeAttr("style").scrollTop(i), j.animate(r, q), m.animate(k, q, function() {
                        m.removeAttr("style"), j.removeAttr("style"), d("html").removeAttr("style"), b = !1, a = !1, "function" == typeof x && x(h)
                    })
                }
            }
        },
        c = {
            open: function(h, g) {
                f.execute("open", h, g)
            },
            close: function(h, g) {
                f.execute("close", h, g)
            },
            toogle: function(h, g) {
                f.execute("toogle", h, g)
            }
        };
    d.sidr = function(e) {
        return c[e] ? c[e].apply(this, Array.prototype.slice.call(arguments, 1)) : "function" != typeof e && "string" != typeof e && e ? (d.error("Method " + e + " does not exist on jQuery.sidr"), void 0) : c.toogle.apply(this, arguments)
    }, d.fn.sidr = function(j) {
        var h = d.extend({
                name: "sidr",
                speed: 200,
                side: "left",
                source: null,
                renaming: !0,
                body: "body"
            }, j),
            p = h.name,
            k = d("#" + p);
        if (0 === k.length && (k = d("<div />").attr("id", p).appendTo(d("body"))), k.addClass("sidr").addClass(h.side).data({
                speed: h.speed,
                side: h.side,
                body: h.body
            }), "function" == typeof h.source) {
            var g = h.source(p);
            f.loadContent(k, g)
        } else {
            if ("string" == typeof h.source && f.isUrl(h.source)) {
                d.get(h.source, function(i) {
                    f.loadContent(k, i)
                })
            } else {
                if ("string" == typeof h.source) {
                    var m = "",
                        e = h.source.split(",");
                    if (d.each(e, function(n, l) {
                            m += '<div class="sidr-inner">' + d(l).html() + "</div>"
                        }), h.renaming) {
                        var o = d("<div />").html(m);
                        o.find("*").each(function(n, l) {
                            var q = d(l);
                            f.addPrefix(q)
                        }), m = o.html()
                    }
                    f.loadContent(k, m)
                } else {
                    null !== h.source && d.error("Invalid Sidr Source")
                }
            }
        }
        return this.each(function() {
            var n = d(this),
                l = n.data("sidr");
            l || (n.data("sidr", p), n.click(function(i) {
                i.preventDefault(), c.toogle(p)
            }))
        })
    }
})(jQuery);
(function() {
    var d, c, a, b = function(e, f) {
        return function() {
            return e.apply(f, arguments)
        }
    };
    d = jQuery;
    c = (function() {
        function e() {}
        e.transitions = {
            webkitTransition: "webkitTransitionEnd",
            mozTransition: "mozTransitionEnd",
            oTransition: "oTransitionEnd",
            transition: "transitionend"
        };
        e.transition = function(g) {
            var i, f, h, j;
            i = g[0];
            j = this.transitions;
            for (h in j) {
                f = j[h];
                if (i.style[h] != null) {
                    return f
                }
            }
        };
        return e
    })();
    a = (function() {
        e.settings = {
            namespace: "growl",
            duration: 3200,
            close: "&times;",
            location: "default",
            style: "default",
            size: "medium"
        };
        e.growl = function(f) {
            if (f == null) {
                f = {}
            }
            this.initialize();
            return new e(f)
        };
        e.initialize = function() {
            return d("body:not(:has(#growls))").append('<div id="growls" />')
        };

        function e(f) {
            if (f == null) {
                f = {}
            }
            this.html = b(this.html, this);
            this.$growl = b(this.$growl, this);
            this.$growls = b(this.$growls, this);
            this.animate = b(this.animate, this);
            this.remove = b(this.remove, this);
            this.dismiss = b(this.dismiss, this);
            this.present = b(this.present, this);
            this.close = b(this.close, this);
            this.cycle = b(this.cycle, this);
            this.unbind = b(this.unbind, this);
            this.bind = b(this.bind, this);
            this.render = b(this.render, this);
            this.settings = d.extend({}, e.settings, f);
            this.$growls().attr("class", this.settings.location);
            this.render()
        }
        e.prototype.render = function() {
            var f;
            f = this.$growl();
            this.$growls().append(f);
            this.cycle(f)
        };
        e.prototype.bind = function(f) {
            if (f == null) {
                f = this.$growl()
            }
            return f.find("." + this.settings.namespace + "-close").on("click", this.close)
        };
        e.prototype.unbind = function(f) {
            if (f == null) {
                f = this.$growl()
            }
            return f.find("." + (this.settings.namespace - close)).off("click", this.close)
        };
        e.prototype.cycle = function(f) {
            if (f == null) {
                f = this.$growl()
            }
            return f.queue(this.present).delay(this.settings.duration).queue(this.dismiss).queue(this.remove)
        };
        e.prototype.close = function(g) {
            var f;
            g.preventDefault();
            g.stopPropagation();
            f = this.$growl();
            return f.stop().queue(this.dismiss).queue(this.remove)
        };
        e.prototype.present = function(g) {
            var f;
            f = this.$growl();
            this.bind(f);
            return this.animate(f, "" + this.settings.namespace + "-incoming", "out", g)
        };
        e.prototype.dismiss = function(g) {
            var f;
            f = this.$growl();
            this.unbind(f);
            return this.animate(f, "" + this.settings.namespace + "-outgoing", "in", g)
        };
        e.prototype.remove = function(f) {
            this.$growl().remove();
            return f()
        };
        e.prototype.animate = function(f, g, h, j) {
            var i;
            if (h == null) {
                h = "in"
            }
            i = c.transition(f);
            f[h === "in" ? "removeClass" : "addClass"](g);
            f.offset().position;
            f[h === "in" ? "addClass" : "removeClass"](g);
            if (j == null) {
                return
            }
            if (i != null) {
                f.one(i, j)
            } else {
                j()
            }
        };
        e.prototype.$growls = function() {
            return this.$_growls != null ? this.$_growls : this.$_growls = d("#growls")
        };
        e.prototype.$growl = function() {
            return this.$_growl != null ? this.$_growl : this.$_growl = d(this.html())
        };
        e.prototype.html = function() {
            return "<div class='" + this.settings.namespace + " " + this.settings.namespace + "-" + this.settings.style + " " + this.settings.namespace + "-" + this.settings.size + "'>\n  <div class='" + this.settings.namespace + "-close'>" + this.settings.close + "</div>\n  <div class='" + this.settings.namespace + "-title'>" + this.settings.title + "</div>\n  <div class='" + this.settings.namespace + "-message'>" + this.settings.message + "</div>\n</div>"
        };
        return e
    })();
    d.growl = function(e) {
        if (e == null) {
            e = {}
        }
        return a.growl(e)
    };
    d.growl.error = function(e) {
        var f;
        if (e == null) {
            e = {}
        }
        f = {
            title: "Error!",
            style: "error"
        };
        return d.growl(d.extend(f, e))
    };
    d.growl.notice = function(e) {
        var f;
        if (e == null) {
            e = {}
        }
        f = {
            title: "Notice!",
            style: "notice"
        };
        return d.growl(d.extend(f, e))
    };
    d.growl.warning = function(e) {
        var f;
        if (e == null) {
            e = {}
        }
        f = {
            title: "Warning!",
            style: "warning"
        };
        return d.growl(d.extend(f, e))
    }
}).call(this);
(function(a) {
    if (typeof define === "function" && define.amd) {
        define(["jquery"], a)
    } else {
        a(jQuery)
    }
}(function(e) {
    var a = /\+/g;

    function d(g) {
        return g
    }

    function b(g) {
        return decodeURIComponent(g.replace(a, " "))
    }

    function f(g) {
        if (g.indexOf('"') === 0) {
            g = g.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\")
        }
        try {
            return c.json ? JSON.parse(g) : g
        } catch (h) {}
    }
    var c = e.cookie = function(p, o, u) {
        if (o !== undefined) {
            u = e.extend({}, c.defaults, u);
            if (typeof u.expires === "number") {
                var q = u.expires,
                    s = u.expires = new Date();
                s.setDate(s.getDate() + q)
            }
            o = c.json ? JSON.stringify(o) : String(o);
            return (document.cookie = [c.raw ? p : encodeURIComponent(p), "=", c.raw ? o : encodeURIComponent(o), u.expires ? "; expires=" + u.expires.toUTCString() : "", u.path ? "; path=" + u.path : "", u.domain ? "; domain=" + u.domain : "", u.secure ? "; secure" : ""].join(""))
        }
        var g = c.raw ? d : b;
        var r = document.cookie.split("; ");
        var v = p ? undefined : {};
        for (var n = 0, k = r.length; n < k; n++) {
            var m = r[n].split("=");
            var h = g(m.shift());
            var j = g(m.join("="));
            if (p && p === h) {
                v = f(j);
                break
            }
            if (!p) {
                v[h] = f(j)
            }
        }
        return v
    };
    c.defaults = {};
    e.removeCookie = function(h, g) {
        if (e.cookie(h) !== undefined) {
            e.cookie(h, "", e.extend({}, g, {
                expires: -1
            }));
            return true
        }
        return false
    }
}));

function addToWishList(a, c) {
    a = a.replace("http:", "");
    a = a.replace("https:", "");
    var b = "/wishlist.php?action=add&product_id=" + c + "&variation_id=";
    jQuery.get(a, {}, function(e) {
        var d = jQuery(e).find("#SideProductAddToWishList");
        if (jQuery(d).find("input[type='radio']").length) {
            $.iModal({
                data: d.html(),
                title: "Add to wishlist",
                width: "300px"
            });
            return false
        } else {
            window.location = b
        }
    });
    return false
}
$(document).ready(function() {
    generateCompareList()
});
var compareListItems = new Array();
var compareList = $.cookie("compare_list");

function addToCompare(b) {
    if (findInList(b) == true) {
        var f = jQuery("#img_" + b).find("img").attr("src");
        var g = jQuery("#link_" + b);
        var c = $.cookie("compare_list");
        var a = new Array();
        if (c != null || c != "") {
            try {
                var h = c.split(",");
                for (var d = 0; d < (h.length / 4); d++) {
                    a.push(Array(h[(d * 4)], h[(d * 4) + 1], h[(d * 4) + 2].replace(",", "%72:"), h[(d * 4) + 3]))
                }
            } catch (e) {}
        }
        a.push(Array(b, f, g.text().replace(",", "%72:"), g.attr("href")));
        var j = '<li id="compare_item_' + b + '" class="compare_item_' + b + '" date-id="' + b + '"><a class="productImgC" href="' + g.attr("href") + '"><img  src="' + f + '"></a><a class="productNameC"  href="' + g.attr("href") + '">' + g.text() + '</a><a class="removeCompare" href="javascript:void(0);" onclick="removeCompareItem(' + b + ');"><i class="fa fa-trash-o"></i></a></li>';
        jQuery("#ComparePanel ul").append(j);
        $.cookie("compare_list", a, {
            expires: 7,
            path: "/"
        });
        $.growl.notice({
            message: "Item added to comparison list"
        });
        compareCountUpdate();
        checklist()
    } else {
        $.growl.warning({
            message: "Item already added for comparison"
        });
        return false
    }
}

function compareCountUpdate() {
    var c = $.cookie("compare_list");
    if (c != null || c != "") {
        try {
            var a = c.split(",");
            var d = a.length / 4;
            if (parseInt(d) <= 1) {
                d = Math.floor(d);
                jQuery(".CompareItem span").html("(" + d + " Item)")
            } else {
                d = Math.floor(d);
                jQuery(".CompareItem span").html("(" + d + " Items)")
            }
        } catch (b) {
            jQuery(".CompareItem span").html("")
        }
    }
}

function findInList(e) {
    var g = $.cookie("compare_list");
    if (g != null || g != "") {
        try {
            var a = g.split(",");
            var f = a.length / 4;
            if (f >= 4) {
                $.growl.warning({
                    message: "You can't compare more then 4 items at a time. Please remove some items from your list"
                });
                return false
            }
            for (var d = 0; d < f; d++) {
                var b = d * 4;
                if (e == a[b]) {
                    return false
                }
            }
        } catch (c) {}
    }
    return true
}

function removeCompareItem(d) {
    $(".compare_item_" + d).remove();
    var e = $.cookie("compare_list");
    var f = new Array();
    if (e != null || e != "") {
        try {
            var a = e.split(",");
            for (var c = 0; c < (a.length / 4); c++) {
                if (parseInt(a[(c * 4)]) != parseInt(d)) {
                    f.push(Array(a[(c * 4)], a[(c * 4) + 1], a[(c * 4) + 2].replace(",", "%72:"), a[(c * 4) + 3]))
                }
            }
            $.cookie("compare_list", f, {
                expires: 7,
                path: "/"
            });
            compareCountUpdate();
            checklist()
        } catch (b) {}
    }
}

function generateCompareList() {
    var e = $.cookie("compare_list");
    if (e != null || e != "") {
        try {
            var a = e.split(",");
            for (var c = 0; c < (a.length / 4); c++) {
                var d = '<li id="compare_item_' + a[(c * 4)] + '" class="compare_item_' + a[(c * 4)] + '" date-id="' + a[(c * 4)] + '"><a class="productImgC" href="' + a[(c * 4) + 3] + '"><img  src="' + a[(c * 4) + 1] + '"></a><a class="productNameC" href="' + a[(c * 4) + 3] + '">' + a[(c * 4) + 2].replace("%72:", ",") + '</a> <a class="removeCompare" href="javascript:void(0)" onclick="removeCompareItem(' + a[(c * 4)] + ')"><i class="glyphicon glyphicon-remove"></i></a></li>';
                jQuery("#ComparePanel ul").append(d)
            }
        } catch (b) {}
    }
    checklist()
}

function checklist() {
    if (jQuery("#ComparePanel ul").html().trim() == "") {
        jQuery(".comparisionBox .empty").show();
        jQuery(".comparisionBox .listing").hide()
    } else {
        jQuery(".comparisionBox .empty").hide();
        jQuery(".comparisionBox .listing").show()
    }
}

function compareNow() {
    var d = $.cookie("compare_list");
    if (d != null || d != "") {
        try {
            var a = d.split(",");
            var e = "";
            for (var c = 0; c < (a.length / 4); c++) {
                e += "/" + a[(c * 4)]
            }
            window.location = "/compare" + e
        } catch (b) {}
    } else {
        alert("No items available for comparison !!!!")
    }
}
jQuery(window).load(compareCountUpdate);


(function(a) {
    a.fn.displayMode = function(b, c) {
        var d = {
            defaultView: "List",
            listSelector: ".disp_list",
            gridSelector: ".disp_grid",
            activeClass: "activemode"
        };
        var b = a.extend(d, b);
        return this.each(function(g, h) {
            var f = a(h);
            if (f.find(".ProductList")) {
                if (b.defaultView == "List") {
                    a(b.listSelector).addClass(b.activeClass)
                } else {
                    a(b.gridSelector).addClass(b.activeClass);
                    f.find(".ProductList").removeClass("List");
                    f.find(".ProductList > li").removeClass("ListView").css("height", "auto");
                    f.find(".ProductList .ProductDescription").hide();
                    f.find(".ProductList .ProductDetails").css("margin", "0")
                }
                a(b.gridSelector).click(function() {
                    a(b.gridSelector).addClass(b.activeClass);
                    a(b.listSelector).removeClass(b.activeClass);
                    f.find(".ProductList").removeClass("List");
                    f.find(".ProductList > li").removeClass("ListView").css("height", "auto");
                    f.find(".ProductList .ProductDescription").hide();
                    f.find(".ProductList .ProductDetails").css("margin", "0")
                });
                a(b.listSelector).click(function() {
                    a(b.listSelector).addClass(b.activeClass);
                    a(b.gridSelector).removeClass(b.activeClass);
                    f.find(".ProductList").addClass("List");
                    f.find(".ProductList > li").addClass("ListView");
                    f.find(".ProductList .ProductDescription").show()
                })
            }
        })
    }
})(jQuery);
(function(a) {
    a.fn.extend({
        easyResponsiveTabs: function(k) {
            var c = {
                type: "default",
                width: "auto",
                fit: true,
                closed: false,
                activate: function() {}
            };
            var k = a.extend(c, k);
            var b = k,
                g = b.type,
                j = b.fit,
                i = b.width,
                e = "vertical",
                f = "accordion";
            var d = window.location.hash;
            var h = !!(window.history && history.replaceState);
            a(this).bind("tabactivate", function(l, m) {
                if (typeof k.activate === "function") {
                    k.activate.call(m, l)
                }
            });
            this.each(function() {
                var p = a(this);
                var t = p.find("ul.resp-tabs-list");
                var s = p.attr("id");
                p.find("ul.resp-tabs-list li").addClass("resp-tab-item");
                p.css({
                    display: "block",
                    width: i
                });
                p.find(".resp-tabs-container > div").addClass("resp-tab-content");
                r();

                function r() {
                    if (g == e) {
                        p.addClass("resp-vtabs")
                    }
                    if (j == true) {
                        p.css({
                            width: "100%",
                            margin: "0px"
                        })
                    }
                    if (g == f) {
                        p.addClass("resp-easy-accordion");
                        p.find(".resp-tabs-list").css("display", "none")
                    }
                }
                var m;
                p.find(".resp-tab-content").before("<h2 class='resp-accordion' role='tab'><span class='resp-arrow'></span></h2>");
                var l = 0;
                p.find(".resp-accordion").each(function() {
                    m = a(this);
                    var w = p.find(".resp-tab-item:eq(" + l + ")");
                    var v = p.find(".resp-accordion:eq(" + l + ")");
                    v.append(w.html());
                    v.data(w.data());
                    m.attr("aria-controls", "tab_item-" + (l));
                    l++
                });
                var q = 0,
                    u;
                p.find(".resp-tab-item").each(function() {
                    $tabItem = a(this);
                    $tabItem.attr("aria-controls", "tab_item-" + (q));
                    $tabItem.attr("role", "tab");
                    var v = 0;
                    p.find(".resp-tab-content").each(function() {
                        u = a(this);
                        u.attr("aria-labelledby", "tab_item-" + (v));
                        v++
                    });
                    q++
                });
                var n = 0;
                if (d != "") {
                    var o = d.match(new RegExp(s + "([0-9]+)"));
                    if (o !== null && o.length === 2) {
                        n = parseInt(o[1], 10) - 1;
                        if (n > q) {
                            n = 0
                        }
                    }
                }
                a(p.find(".resp-tab-item")[n]).addClass("resp-tab-active");
                if (k.closed !== true && !(k.closed === "accordion" && !t.is(":visible")) && !(k.closed === "tabs" && t.is(":visible"))) {
                    a(p.find(".resp-accordion")[n]).addClass("resp-tab-active");
                    a(p.find(".resp-tab-content")[n]).addClass("resp-tab-content-active").attr("style", "display:block")
                } else {
                    a(p.find(".resp-tab-content")[n]).addClass("resp-tab-content-active resp-accordion-closed")
                }
                p.find("[role=tab]").each(function() {
                    var v = a(this);
                    v.click(function() {
                        var A = a(this);
                        var w = A.attr("aria-controls");
                        if (A.hasClass("resp-accordion") && A.hasClass("resp-tab-active")) {
                            p.find(".resp-tab-content-active").slideUp("", function() {
                                a(this).addClass("resp-accordion-closed")
                            });
                            A.removeClass("resp-tab-active");
                            return false
                        }
                        if (!A.hasClass("resp-tab-active") && A.hasClass("resp-accordion")) {
                            p.find(".resp-tab-active").removeClass("resp-tab-active");
                            p.find(".resp-tab-content-active").slideUp().removeClass("resp-tab-content-active resp-accordion-closed");
                            p.find("[aria-controls=" + w + "]").addClass("resp-tab-active");
                            p.find(".resp-tab-content[aria-labelledby = " + w + "]").slideDown().addClass("resp-tab-content-active")
                        } else {
                            p.find(".resp-tab-active").removeClass("resp-tab-active");
                            p.find(".resp-tab-content-active").removeAttr("style").removeClass("resp-tab-content-active").removeClass("resp-accordion-closed");
                            p.find("[aria-controls=" + w + "]").addClass("resp-tab-active");
                            p.find(".resp-tab-content[aria-labelledby = " + w + "]").addClass("resp-tab-content-active").attr("style", "display:block")
                        }
                        A.trigger("tabactivate", A);
                        if (h) {
                            var z = window.location.hash;
                            var y = s + (parseInt(w.substring(9), 10) + 1).toString();
                            if (z != "") {
                                var x = new RegExp(s + "[0-9]+");
                                if (z.match(x) != null) {
                                    y = z.replace(x, y)
                                } else {
                                    y = z + "|" + y
                                }
                            } else {
                                y = "#" + y
                            }
                            history.replaceState(null, null, y)
                        }
                    })
                });
                a(window).resize(function() {
                    p.find(".resp-accordion-closed").removeAttr("style")
                })
            })
        }
    })
})(jQuery);